import React from 'react';

const ImageBlock = () => {
    return (
        <div className="image-block">
            <input type="file" accept="image/*" />
        </div>
    );
};

export default ImageBlock;
