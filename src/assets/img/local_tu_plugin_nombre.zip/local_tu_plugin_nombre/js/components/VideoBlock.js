import React from 'react';

const VideoBlock = () => {
    return (
        <div className="video-block">
            <input type="file" accept="video/*" />
        </div>
    );
};

export default VideoBlock;
