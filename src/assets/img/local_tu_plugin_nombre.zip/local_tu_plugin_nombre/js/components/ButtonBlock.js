import React from 'react';

const ButtonBlock = () => {
    return (
        <div className="button-block">
            <button>Click Me</button>
        </div>
    );
};

export default ButtonBlock;
