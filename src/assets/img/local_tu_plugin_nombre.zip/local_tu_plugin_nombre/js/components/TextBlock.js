import React from 'react';

const TextBlock = () => {
    return (
        <div className="text-block">
            <textarea placeholder="Enter text here"></textarea>
        </div>
    );
};

export default TextBlock;
