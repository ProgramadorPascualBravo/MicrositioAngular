import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import TextBlock from './components/TextBlock';
import ImageBlock from './components/ImageBlock';
import VideoBlock from './components/VideoBlock';
import ButtonBlock from './components/ButtonBlock';

const Editor = () => {
    const [blocks, setBlocks] = useState([]);

    const addBlock = (type) => {
        setBlocks([...blocks, { type, id: Date.now() }]);
    };

    return (
        <div>
            <div className="toolbar">
                <button onClick={() => addBlock('text')}>Add Text</button>
                <button onClick={() => addBlock('image')}>Add Image</button>
                <button onClick={() => addBlock('video')}>Add Video</button>
                <button onClick={() => addBlock('button')}>Add Button</button>
            </div>
            <div className="editor">
                {blocks.map(block => {
                    switch (block.type) {
                        case 'text':
                            return <TextBlock key={block.id} />;
                        case 'image':
                            return <ImageBlock key={block.id} />;
                        case 'video':
                            return <VideoBlock key={block.id} />;
                        case 'button':
                            return <ButtonBlock key={block.id} />;
                        default:
                            return null;
                    }
                })}
            </div>
        </div>
    );
};

ReactDOM.render(<Editor />, document.getElementById('editor-root'));
