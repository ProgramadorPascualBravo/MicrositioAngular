<?php
$string['pluginname'] = 'Tu Plugin Nombre';
?>
