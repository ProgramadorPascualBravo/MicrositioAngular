<?php
$plugin->component = 'local_tu_plugin_nombre';
$plugin->version = 2024072900;
$plugin->requires = 2020110900; // Moodle 3.10
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = 'v0.1';
